package homeWork003;

public class hourlyEmployee extends staffMember {
    private int hoursWorked;
    private double rate;
//    private double payment;

    public hourlyEmployee(int id, String name, String address, Integer hoursWorked, Double rate) {
        super(id, name, address);
        this.hoursWorked = hoursWorked;
        this.rate = rate;
//        this.payment = payment;
//        super(hoursWorked);
    }

    @Override
    public String toString() {
        // for convert to capital letter
        String n = name;
        StringBuilder sb = new StringBuilder(n.length());
        String [] words = n.split("\\ ");
        for(int i = 0; i < words.length; i++){
            sb.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
        }
        //end
        return "ID : " + id + "\nName : " + sb + "\nAddress: " + address + "\nHours Worked : " + hoursWorked + "\nRate : " + rate + "\nPayment : " + pay();
    }

    @Override
    public double pay() {
        return hoursWorked * rate;
    }

    public void setHoursWorked(int hoursWorked){
        this.hoursWorked = hoursWorked;
    }
    public int getHoursWorked(){
        return hoursWorked;
    }
    public void setRate(double rate){
        this.rate = rate;
    }
    public double getRate(){
        return rate;
    }
}



