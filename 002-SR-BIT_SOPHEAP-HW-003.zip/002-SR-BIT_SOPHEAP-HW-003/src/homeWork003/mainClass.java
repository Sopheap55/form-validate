package homeWork003;

import java.util.*;

public class mainClass {
    int choose;
    int ch;
    Scanner input = new Scanner(System.in).useLocale(Locale.US);
    volunteer a = new volunteer(4, "Dara", "pp" );
    hourlyEmployee b = new hourlyEmployee(4, "dara", "pp", 20, 100.0);
    salariedEmployee c = new salariedEmployee(4, "dara", "pp", 200.50, 2.3);
    public void display() throws Exception{
        ArrayList<volunteer> vol = new ArrayList<>();
        vol.add(new volunteer(1, "sam", "123 Main Love"));
        for(volunteer s : vol){
            System.out.println();
            System.out.println(s);
            System.out.println("------------------------------------------------------------------\n");
        }
        ArrayList<hourlyEmployee> horEmp = new ArrayList<>();
        horEmp.add(new hourlyEmployee(2, "diane", "678 Fifth Ave",20, 600.50));
        for(hourlyEmployee h : horEmp){
            System.out.println();
            System.out.println(h);
            System.out.println("------------------------------------------------------------------\n");

        }
        ArrayList<salariedEmployee> salEmp = new ArrayList<>();
        salEmp.add(new salariedEmployee(3, "carla", "456 Off Line", 1246.15, 345.9));
        for(salariedEmployee sa : salEmp){
            System.out.println();
            System.out.println(sa);
            System.out.println("------------------------------------------------------------------\n");

        }
        //for Menu
        outer:
        do {
            System.out.println("------------------------------------------------------------------");
            System.out.println("1). Add Employee       2). Edit     3). Remove      4). Exit\n");
            System.out.print("\n==> Choose option(1-4) : ");
            choose = input.nextInt();

            switch (choose) {
                case 1:
                        System.out.println("\n------------------------------------------------------------------");
                        System.out.println("1). Volunteer       2). Hourly Emp     3). Salaried Emp      4). Back\n");
                        System.out.print("\n==> Choose option(1-4) : ");
                        ch = input.nextInt();
                        switch (ch) {
                            case 1:
                                System.out.println("\n========================INSERT INFORMATION========================");
                                System.out.print("Enter Staff Member's ID : ");
                                a.setId(input.nextInt());
                                System.out.print("\nEnter Staff Member's Name : ");
                                input.nextLine();
                                a.setName(input.nextLine());
                                System.out.print("\nEnter Staff Member's Address : ");
                                a.setAddress(input.nextLine());
                                vol.add(a);
                                for (volunteer v : vol) {
                                    System.out.println();
                                    System.out.println(v);
                                    System.out.println("------------------------------------------------------------------\n");
                                }
                                for (hourlyEmployee h : horEmp) {
                                    System.out.println();
                                    System.out.println(h);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                for (salariedEmployee sa : salEmp) {
                                    System.out.println();
                                    System.out.println(sa);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                break;
                            case 2:
                                System.out.println("\n========================INSERT INFORMATION========================");
                                System.out.print("Enter Staff Member's ID : ");
                                b.setId(input.nextInt());
                                System.out.print("\nEnter Staff Member's Name : ");
                                input.nextLine();
                                b.setName(input.nextLine());
                                System.out.print("\nEnter Staff Member's Address : ");
                                b.setAddress(input.nextLine());
                                System.out.print("\nEnter Hours Worked : ");
                                b.setHoursWorked(input.nextInt());
                                System.out.print("\nEnter Rate : ");
                                b.setRate(input.nextDouble());
                                horEmp.add(b);
                                for (volunteer v : vol) {
                                    System.out.println();
                                    System.out.println(v);
                                    System.out.println("------------------------------------------------------------------\n");
                                }
                                for (hourlyEmployee h : horEmp) {
                                    System.out.println();
                                    System.out.println(h);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                for (salariedEmployee sa : salEmp) {
                                    System.out.println();
                                    System.out.println(sa);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                break;
                            case 3:
                                System.out.println("\n========================INSERT INFORMATION========================");
                                System.out.print("Enter Staff Member's ID : ");
                                c.setId(input.nextInt());
                                System.out.print("\nEnter Staff Member's Name : ");
                                input.nextLine();
                                c.setName(input.nextLine());
                                System.out.print("\nEnter Staff Member's Address : ");
                                c.setAddress(input.nextLine());
                                System.out.print("\nEnter Staff's Salary : ");
                                c.setSalary(input.nextDouble());
                                System.out.print("\nEnter Staff's Bonus : ");
                                c.setBonus(input.nextDouble());
                                salEmp.add(c);
                                for (volunteer v : vol) {
                                    System.out.println();
                                    System.out.println(v);
                                    System.out.println("------------------------------------------------------------------\n");
                                }
                                for (hourlyEmployee h : horEmp) {
                                    System.out.println();
                                    System.out.println(h);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                for (salariedEmployee sa : salEmp) {
                                    System.out.println();
                                    System.out.println(sa);
                                    System.out.println("------------------------------------------------------------------\n");

                                }
                                break;
                            case 4:
                                System.out.println("\nMenu is backed...\n\n");
                                continue outer;
//                                break;
                            default:
                                System.out.println("\n***__Please input number from 1 to 4__***\n");
                                break;
                        }
                    break;
                case 2:
                    System.out.println("\n========================EDIT INFORMATION========================");
                    System.out.println("Enter Employee to Update : ");
                    int id = input.nextInt();
                    break;
                case 3:
                    System.out.println("\n========================INSERT INFORMATION========================");
                    System.out.print("Enter Employee ID to remove : ");
                    id = input.nextInt();
                    break;
                case 4:
                    System.out.println("\n--------Good Bye---------\n");
                    System.exit(0);
                    break;
                default:
                    System.out.println();
                    System.out.println("***__Please input number from 1 to 4__***");
                    System.out.println();
                    break;
            }
        }while (choose != 4);
    }


    public static void main(String[] args) throws Exception {
        mainClass main = new mainClass();
        main.display();
    }
}
