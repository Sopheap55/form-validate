package homeWork003;

public class salariedEmployee extends staffMember {
    private double salary;
    private double bonus;

    public salariedEmployee(int id, String name, String address, double salary, double bonus) {
        super(id,name,address);
        this.salary = salary;
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        // for convert to capital letter
        String n = name;
        StringBuilder sb = new StringBuilder(n.length());
        String [] words = n.split("\\ ");
        for(int i = 0; i < words.length; i++){
            sb.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
        }
        //end
        return "ID : " + id + "\nName : " + sb + "\nAddress : " + address + "\nSalary : " + salary + "\nBonus : " + bonus + "\nPayment : " + pay();
    }
    @Override
    public double pay() {
        return salary + bonus;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
}
