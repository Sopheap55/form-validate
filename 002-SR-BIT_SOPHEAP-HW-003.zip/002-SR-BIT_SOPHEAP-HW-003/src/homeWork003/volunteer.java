package homeWork003;

public class volunteer extends staffMember{

    public volunteer(int id, String name, String address) {
        super(id, name, address);

    }

    @Override
    public String toString() {
        // for convert to capital letter
        String n = this.name;
        StringBuilder sb = new StringBuilder(n.length());
        String [] words = n.split("\\ ");
        for(int i = 0; i < words.length; i++){
            sb.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
        }
        //end
        return "ID : " + id + "\nName : " + sb + "\nAddress : " + this.address + "\nThank!";
    }

    @Override
    public double pay() {
        return 0;
    }


}
